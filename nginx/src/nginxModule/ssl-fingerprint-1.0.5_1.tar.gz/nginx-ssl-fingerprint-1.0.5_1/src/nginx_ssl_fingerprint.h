
/*
 * Obj: nginx_ssl_fingerprint.c
 */

#ifndef NGINX_SSL_FINGERPRINT_H_
#define NGINX_SSL_FINGERPRINT_H_ 1


#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>

/* HTTP/3: c->ssl is shared across all QUIC request streams while c->pool is
 * per-stream. Pin cached JA3/JA4 buffers to the connection-lifetime pool
 * captured in the ClientHello callback (fp_pool), else they dangle when a
 * stream ends. For HTTP/1.x and HTTP/2, fp_pool == c->pool, so no change. */
#define NGX_SSL_FP_POOL(c)  ((c)->ssl->fp_pool ? (c)->ssl->fp_pool : (c)->pool)

int ngx_ssl_ja3(ngx_connection_t *c);
int ngx_ssl_ja3_hash(ngx_connection_t *c);
int ngx_ssl_ja4(ngx_connection_t *c);
int ngx_http2_fingerprint(ngx_connection_t *c, ngx_http_v2_connection_t *h2c);

#endif /** NGINX_SSL_FINGERPRINT_H_ */

