/*---
includes: [compatFs.js, compatNjs.js, runTsuite.js]
flags: [async]
---*/

import xml from 'xml';

function has_quickjs() {
    return (typeof njs != 'undefined' && njs.engine == 'QuickJS');
}

let parse_tsuite = {
    name: "parse()",
    skip: () => (!has_njs()),
    T: async (params) => {
        let doc = xml.parse(params.doc);
        let r = params.get(doc);

        if (r !== params.expected) {
            throw Error(`unexpected output "${r}" != "${params.expected}"`);
        }

        return 'SUCCESS';
    },

    opts: {
        doc: `<note><to b=\"bar\" a= \"foo\" >Tove</to><from>Jani</from></note>`,
    },

    tests: [
        { get: (doc) => doc.nonexist, expected: undefined },
        { get: (doc) => doc.note.$name, expected: 'note' },
        { get: (doc) => doc.note.$text, expected: 'ToveJani' },
        { get: (doc) => doc.note.to.$text, expected: 'Tove' },
        { get: (doc) => doc.note.$tag$to.$text, expected: 'Tove' },
        { get: (doc) => doc.note.$attrs, expected: undefined },
        { get: (doc) => doc.note.to.$attrs.a, expected: 'foo' },
        { get: (doc) => doc.note.to.$attrs.b, expected: 'bar' },
        { get: (doc) => doc.note.to.$attr$b, expected: 'bar' },
        { get: (doc) => doc.note.$attr$a, expected: undefined },
        { get: (doc) => '$attr$a' in doc.note.to, expected: true },
        { get: (doc) => '$attr$missing' in doc.note.to, expected: false },
        { get: (doc) => 'to' in doc.note, expected: true },
        { get: (doc) => 'missing' in doc.note, expected: false },
        { get: (doc) => '$tags$to' in doc.note, expected: true },
        { get: (doc) => Array.isArray(doc.note.$tags), expected: true },
        { get: (doc) => doc.note.$tags[0].$text, expected: 'Tove' },
        { get: (doc) => doc.note.$tags[1].$text, expected: 'Jani' },
        { get: (doc) => doc.note.$tags$from[0].$text, expected: 'Jani' },
        { get: (doc) => doc.note.$parent, expected: undefined },
        { get: (doc) => doc.note.to.$parent.$name, expected: 'note' },
        { doc: `<n0:pdu xmlns:n0=\"http://a\"></n0:pdu>`,
          get: (doc) => doc.pdu.$ns,
          expected: 'http://a' },
        { doc: `<r xmlns:x="urn:other" x:ID="wrong" ID="correct">`
               + `<x:Issuer>foreign</x:Issuer><Issuer>trusted</Issuer></r>`,
          get: (doc) => [
              doc.r.getAttributeNS('', 'ID'),
              doc.r.getAttributeNS(null, 'ID'),
              doc.r.getAttributeNS('urn:other', 'ID'),
              doc.r.getAttributeNS('urn:missing', 'ID'),
              doc.r.getChildNS('', 'Issuer').$text,
              doc.r.getChildNS(null, 'Issuer').$text,
              doc.r.getChildNS('urn:other', 'Issuer').$text,
              doc.r.getChildNS('urn:missing', 'Issuer')].join(','),
          expected: 'correct,correct,wrong,,trusted,trusted,foreign,' },
        { doc: `<r xmlns="urn:d" ID="plain"><c/></r>`,
          get: (doc) => [
              doc.r.getAttributeNS(null, 'ID'),
              doc.r.getAttributeNS('urn:d', 'ID'),
              doc.r.getChildNS(null, 'c'),
              doc.r.getChildNS('urn:d', 'c').$name].join(','),
          expected: 'plain,,,c' },
        { doc: `<r xml:lang="en"/>`,
          get: (doc) => doc.r.getAttributeNS(
                            'http://www.w3.org/XML/1998/namespace', 'lang'),
          expected: 'en' },
        { doc: `<r><a><b/></a></r>`,
          get: (doc) => doc.r.getChildNS(null, 'b'),
          expected: undefined },
        { doc: `<r><!--c--><?p?>text<c/></r>`,
          get: (doc) => doc.r.getChildNS(null, 'c').$name,
          expected: 'c' },
        { doc: `<r ID="ok"><addChild/><getAttributeNS/><getChildNS/>`
               + `<removeChildren/><setAttribute/><removeAttribute/>`
               + `<removeAllAttributes/><setText/><removeText/>`
               + `<Issuer>trusted</Issuer></r>`,
          get: (doc) => {
              const node = doc.r;
              const methods = ['addChild', 'getAttributeNS', 'getChildNS',
                               'removeChildren', 'setAttribute',
                               'removeAttribute', 'removeAllAttributes',
                               'setText', 'removeText'];

              return methods.every(name => typeof node[name] == 'function'
                             && node[`$tag$${name}`].$name == name)
                     && node.getAttributeNS(null, 'ID') == 'ok'
                     && node.getChildNS(null, 'Issuer').$text == 'trusted';
          },
          expected: true },
        { doc: `<r><getChildNS/></r>`,
          get: (doc) => {
              delete doc.r.$tag$getChildNS;
              return typeof doc.r.getChildNS == 'function'
                     && doc.r.$tag$getChildNS === undefined;
          },
          expected: true },
        { doc: `<r><setAttribute/></r>`,
          skip: () => !has_quickjs(),
          get: (doc) => {
              delete doc.r.setAttribute;
              return typeof doc.r.setAttribute == 'function'
                     && doc.r.$tag$setAttribute.$name == 'setAttribute';
          },
          expected: true },
        { doc: `<r><getChildNS/></r>`,
          skip: () => !has_quickjs(),
          get: (doc) => {
              const proto = Object.getPrototypeOf(doc.r);
              const method = proto.getChildNS;

              delete proto.getChildNS;

              try {
                  return doc.r.getChildNS.$name == 'getChildNS';

              } finally {
                  proto.getChildNS = method;
              }
          },
          expected: true },
        { doc: `<!DOCTYPE r [<!ENTITY e "complete">]>`
               + `<r xmlns:x="urn:other" x:ID="pre&e;post"/>`,
          get: (doc) => doc.r.getAttributeNS('urn:other', 'ID'),
          expected: 'precompletepost' },
        { get: (doc) => doc.note.getChildNS(undefined, 'to'),
          exception: 'TypeError: namespace URI is not a string or null' },
        { get: (doc) => doc.note.getAttributeNS(1, 'a'),
          exception: 'TypeError: namespace URI is not a string or null' },
        { get: (doc) => doc.note.getChildNS(null),
          exception: 'TypeError: local name is not a string' },
        { get: (doc) => doc.note.to.getAttributeNS(null, null),
          exception: 'TypeError: local name is not a string' },
        { get: (doc) => doc.note.getChildNS.call({}, null, 'to'),
          exception: 'TypeError: "this" is not a XMLNode object' },
        { doc: `<root><foo>FOO</foo><foo>BAR</foo></root>`,
          get: (doc) => doc.root.$tags$foo[0].$text,
          expected: 'FOO' },
        { doc: `<root><foo>FOO</foo><foo>BAR</foo></root>`,
          get: (doc) => doc.root.$tags$foo[1].$text,
          expected: 'BAR' },
        { doc: `<root><foo>FOO</foo><foo>BAR</foo></root>`,
          get: (doc) => doc.root.$tags$bar.length,
          expected: 0 },
        { doc: `<root><foo>FOO</foo><foo>BAR</foo></root>`,
          get: (doc) => doc.root.$tags.length,
          expected: 2 },
        { doc: `<r><a></a>TEXT</r>`,
          get: (doc) => doc.r.$text,
          expected: 'TEXT' },
        { doc: `<r><a></a>TEXT</r>`,
          get: (doc) => doc.$root.$text,
          expected: 'TEXT' },
        { doc: `<r>俄语<a></a>данные</r>`,
          get: (doc) => doc.r.$text[2],
          expected: 'д' },
        { doc: `<俄语 լեզու=\"ռուսերեն\">данные</俄语>`,
          get: (doc) => JSON.stringify([doc['俄语'].$name[1],doc['俄语']['$attr$լեզու'][7],doc['俄语'].$text[5]]),
          expected: '["语","ն","е"]' },

        { doc: `<!DOCTYPE r [<!ENTITY e "value">]><r a="&e;"/>`,
          get: (doc) => JSON.stringify([doc.r.$attr$a, doc.r.$attrs.a]),
          expected: '["value","value"]' },
        { doc: `<!DOCTYPE r [<!ENTITY e "middle">]><r a="left-&e;-right"/>`,
          get: (doc) => JSON.stringify([doc.r.$attr$a, doc.r.$attrs.a,
                                        xml.serializeToString(doc.r)]),
          expected: '["left-middle-right","left-middle-right",'
                    + '"<r a=\\"left-middle-right\\"></r>"]' },
        { doc: `<!DOCTYPE r [<!ENTITY a "A"><!ENTITY b "&a;B">]><r a="&b;"/>`,
          get: (doc) => JSON.stringify([doc.r.$attr$a, doc.r.$attrs.a]),
          expected: '["AB","AB"]' },
        { doc: `<!DOCTYPE r [<!ENTITY e "">]><r a="&e;"/>`,
          get: (doc) => JSON.stringify([doc.r.$attr$a, doc.r.$attrs.a]),
          expected: '["",""]' },
        { doc: `<!DOCTYPE r [<!ATTLIST r a CDATA "default">]><r/>`,
          get: (doc) => JSON.stringify([doc.r.$attr$a, doc.r.$attrs]),
          expected: '[null,null]' },

        { get: (doc) => JSON.stringify(Object.getOwnPropertyNames(doc)),
          expected: '["note"]' },
        { get: (doc) => JSON.stringify(Object.getOwnPropertyNames(doc.note)),
          expected: '["$name","$tags"]' },
        { get: (doc) => JSON.stringify(Object.getOwnPropertyNames(doc.note.to)),
          expected: '["$name","$attrs","$text"]' },

        { get: (doc) => JSON.stringify(doc.note.to.$attrs),
          expected: '{"b":"bar","a":"foo"}' },
        { get: (doc) => JSON.stringify(doc.note.$tags),
          expected: '[{"$name":"to","$attrs":{"b":"bar","a":"foo"},"$text":"Tove"},{"$name":"from","$text":"Jani"}]' },
        { get: (doc) => JSON.stringify(doc),
          expected: '{"note":{"$name":"note","$tags":[{"$name":"to","$attrs":{"b":"bar","a":"foo"},"$text":"Tove"},{"$name":"from","$text":"Jani"}]}}' },
        { get: (doc) => JSON.stringify(doc.note),
            expected: '{"$name":"note","$tags":[{"$name":"to","$attrs":{"b":"bar","a":"foo"},"$text":"Tove"},{"$name":"from","$text":"Jani"}]}' },

        { doc: `GARBAGE`,
          exception: 'Error: failed to parse XML (libxml2: "Start tag expected, \'<\' not found" at 1:1)' },
]};

let parse_failure_tsuite = {
    name: "parse() failures",
    skip: () => (!has_njs()),
    T: async (params) => {
        for (let i = 0; i < params.count; i++) {
            try {
                xml.parse(params.doc);
            } catch (e) {
                continue;
            }

            throw Error('missing exception');
        }

        return 'SUCCESS';
    },

    opts: {
        count: 2,
        doc: 'GARBAGE',
    },

    tests: [
        {},
    ],
};

let c14n_tsuite = {
    name: "c14n()",
    skip: () => (!has_njs()),
    T: async (params) => {
        let doc = xml.parse(params.doc);
        let r = params.call(doc);

        if (params.buffer) {
            r = new TextDecoder().decode(r);
        }

        if (r !== params.expected) {
            throw Error(`unexpected output "${r}" != "${params.expected}"`);
        }

        return 'SUCCESS';
    },

    opts: {
        buffer: true,
        doc: `<n0:pdu xmlns:n0=\"http://a\"><n1:elem1 xmlns:n1=\"http://b\"><!-- comment -->foo</n1:elem1></n0:pdu>`,
    },

    tests: [
        { call: (doc) => xml.c14n(doc.pdu.elem1),
          expected: `<n1:elem1 xmlns:n0="http://a" xmlns:n1="http://b">foo</n1:elem1>` },
        { call: (doc) => xml.serialize(doc.pdu.elem1),
          expected: `<n1:elem1 xmlns:n0="http://a" xmlns:n1="http://b">foo</n1:elem1>` },
        { call: (doc) => xml.serializeToString(doc.pdu.elem1),
          buffer: false,
          expected: `<n1:elem1 xmlns:n0="http://a" xmlns:n1="http://b">foo</n1:elem1>` },
        { call: (doc) => xml.exclusiveC14n(doc.pdu.elem1),
          expected: `<n1:elem1 xmlns:n1="http://b">foo</n1:elem1>` },
        { call: (doc) => xml.exclusiveC14n(doc.pdu.elem1, null, true),
          expected: `<n1:elem1 xmlns:n1="http://b"><!-- comment -->foo</n1:elem1>` },
        { call: (doc) => xml.exclusiveC14n(doc.pdu.elem1, null, false, 'n1'),
          expected: `<n1:elem1 xmlns:n1="http://b">foo</n1:elem1>` },
        { call: (doc) => xml.exclusiveC14n(doc.pdu.elem1, null, false, 'a b c d e f g h i j'),
          expected: `<n1:elem1 xmlns:n1="http://b">foo</n1:elem1>` },
        { call: (doc) => xml.exclusiveC14n(doc.pdu.elem1, null, false,
                                           'a '.repeat(7) + 'n0'),
          expected: `<n1:elem1 xmlns:n0="http://a" xmlns:n1="http://b">foo</n1:elem1>` },
        { call: (doc) => xml.exclusiveC14n(doc.pdu.elem1, null, false,
                                           'a '.repeat(15) + 'n0'),
          expected: `<n1:elem1 xmlns:n0="http://a" xmlns:n1="http://b">foo</n1:elem1>` },
        { call: (doc) => xml.exclusiveC14n(doc.pdu.elem1, null, false,
                                           'a '.repeat(127) + 'n0'),
          expected: `<n1:elem1 xmlns:n0="http://a" xmlns:n1="http://b">foo</n1:elem1>` },
        { call: (doc) => xml.exclusiveC14n(doc.pdu.elem1, null, false,
                                           '  n0   a  '),
          expected: `<n1:elem1 xmlns:n0="http://a" xmlns:n1="http://b">foo</n1:elem1>` },
        { call: (doc) => xml.exclusiveC14n(doc.pdu.elem1, null, false,
                                           'a\tn0\r\nb'),
          expected: `<n1:elem1 xmlns:n0="http://a" xmlns:n1="http://b">foo</n1:elem1>` },
        { doc: `<r xmlns="http://d" xmlns:p="http://p"><p:b>x</p:b></r>`,
          call: (doc) => xml.exclusiveC14n(doc.r.b, null, false, '#default'),
          expected: `<p:b xmlns="http://d" xmlns:p="http://p">x</p:b>` },
        { doc: `<r xmlns="http://d" xmlns:p="http://p"><p:b>x</p:b></r>`,
          call: (doc) => xml.exclusiveC14n(doc.r.b, null, false, ' a  b '),
          expected: `<p:b xmlns:p="http://p">x</p:b>` },
        { call: (doc) => {
              let prefixes = 'n0 n1';
              xml.exclusiveC14n(doc.pdu.elem1, null, false, prefixes);
              return prefixes;
          },
          buffer: false,
          expected: 'n0 n1' },
        { doc: `<note><to a="foo" b="bar">Tove</to><from>Jani</from></note>`,
          call: (doc) => xml.c14n(doc.note),
          expected: `<note><to a="foo" b="bar">Tove</to><from>Jani</from></note>` },
        { doc: `<note><to a="foo" b="bar">Tove</to><from>Jani</from></note>`,
          call: (doc) => xml.exclusiveC14n(doc.note),
          expected: `<note><to a="foo" b="bar">Tove</to><from>Jani</from></note>` },
        { doc: `<note><to a="foo" b="bar">Tove</to><from>Jani</from></note>`,
          call: (doc) => xml.exclusiveC14n(doc.note, doc.note.to),
          expected: `<note><from>Jani</from></note>` },
        { doc: `<!DOCTYPE r [<!ENTITY e "middle">]><r a="left-&e;-right"/>`,
          call: (doc) => xml.c14n(doc.r),
          expected: `<r a="left-middle-right"></r>` },
        { doc: `<r><a>A</a></r>`,
          call: (doc) => {
              let other = xml.parse(`<other></other>`);
              return xml.exclusiveC14n(doc.r, other.other);
          },
          exception: 'TypeError: "excluding" is not in XMLNode tree' },
        { doc: `<r><a>A</a></r>`,
          call: (doc) => {
              let a = doc.r.a;
              doc.r.removeChildren('a');
              return xml.exclusiveC14n(doc.r, a);
          },
          exception: 'TypeError: "excluding" is not in XMLNode tree' },
        { doc: `<r></r>`,
          call: (doc) => xml.exclusiveC14n(doc, 1),
          exception: 'TypeError: "excluding" argument is not a XMLNode object' },
]};

let modify_tsuite = {
    name: "modifying XML",
    skip: () => (!has_njs()),
    T: async (params) => {
        let doc = xml.parse(params.doc);
        let r = params.get(doc);

        if (r !== params.expected) {
            throw Error(`unexpected output "${r}" != "${params.expected}"`);
        }

        return 'SUCCESS';
    },

    opts: {
        doc: `<note><to b=\"bar\" a= \"foo\" >Tove</to><from>Jani</from></note>`,
    },

    tests: [
        { get: (doc) => {
            doc.note.setText('WAKA');
            return doc.note.$text;
          },
          expected: 'WAKA' },
        { get: (doc) => {
            doc.note.setText('WAKA');
            doc.note.setText('OVERWRITE');
            return doc.note.$text;
          },
          expected: 'OVERWRITE' },
        { get: (doc) => {
            let note = doc.note;
            note.setText('WAKA');
            note.setText('OVERWRITE');
            return note.$text;
          },
          expected: 'OVERWRITE' },
        { get: (doc) => {
            let note = doc.note;
            note.setText('WAKA');
            return doc.note.$text;
          },
          expected: 'WAKA' },
        { get: () => {
            let mutations = [
                (node) => node.setText('first'),
                (node) => node.removeText(),
                (node) => node.removeChildren(),
                (node) => node.removeChildren('a'),
                (node, doc) => node.addChild(doc.r.b),
                (node) => { delete node.$tag$a; },
                (node, doc) => { node.$tags = [doc.r.a]; },
                (node) => { delete node.$tags; },
            ];
            let passed = 0;

            for (let i = 0; i < mutations.length; i++) {
                for (let j = 0; j < 2; j++) {
                    let current = xml.parse(`<r><a>A</a><b>B</b></r>`);
                    let first = current.r;
                    let second = current.r;
                    let mutate = mutations[i];
                    let reverse = (j != 0);
                    let target = reverse ? second : first;
                    let alias = reverse ? first : second;

                    mutate(target, current);
                    alias.setText('final');

                    if (first.$text != 'final'
                        || second.$text != 'final'
                        || current.r.$text != 'final')
                    {
                        return false;
                    }

                    passed++;
                }
            }

            return passed;
          },
          expected: 16 },
        { get: (doc) => {
            let direct = doc.note;
            let root = doc.$root;
            let parent = doc.note.to.$parent;
            let tag = doc.note.$tag$to.$parent;
            let tags = doc.note.$tags$to[0].$parent;

            direct.setText('direct');
            root.setText('root');
            parent.setText('parent');
            tag.setText('tag');
            tags.setText('tags');

            return [direct.$text, root.$text, parent.$text, tag.$text,
                    tags.$text, doc.note.$text].toString();
          },
          expected: 'tags,tags,tags,tags,tags,tags' },
        { get: (doc) => {
            let to = doc.note.to;
            let attrs = to.$attrs;

            to.setText('changed');
            to.setAttribute('a', 'updated');

            return [attrs.a, to.$text, doc.note.to.$text].toString();
          },
          expected: 'updated,changed,changed' },
        { get: (doc) => {
            doc.note.setText('WAKA');
            return xml.serializeToString(doc);
          },
          expected: `<note>WAKA</note>` },
        { get: (doc) => {
            doc.note.$text = '<WA&KA>';
            return xml.serializeToString(doc);
          },
          expected: `<note>&lt;WA&amp;KA&gt;</note>` },
        { get: (doc) => {
            doc.note.$text = '';
            return xml.serializeToString(doc);
          },
          expected: `<note></note>` },
        { get: (doc) => {
            doc.note.setText('<WA&KA>');
            return doc.note.$text;
          },
          expected: '<WA&KA>' },
        { get: (doc) => {
            doc.note.setText('<WA&KA>');
            return xml.serializeToString(doc);
          },
          expected: `<note>&lt;WA&amp;KA&gt;</note>` },
        { get: (doc) => {
            doc.note.setText('"WAKA"');
            return xml.serializeToString(doc);
          },
          expected: `<note>"WAKA"</note>` },
        { get: (doc) => {
            doc.note.setText('');
            return doc.note.$text;
          },
          expected: '' },
        { get: (doc) => {
            doc.note.setText('');
            return xml.serializeToString(doc);
          },
          expected: `<note></note>` },
        { get: (doc) => {
            try {
                doc.note.setText('before\0after');
            } catch (e) {
                return [e instanceof TypeError, doc.note.$text].toString();
            }

            return 'missing exception';
          },
          expected: 'true,ToveJani' },
        { get: (doc) => {
            let called = false;
            let value = {toString: () => {
                called = true;
                doc.note.removeChildren();
                return 'changed';
            }};

            try {
                doc.note.setText(value);
            } catch (e) {
                return [called, e instanceof TypeError,
                        xml.serializeToString(doc)].toString();
            }

            return 'missing exception';
          },
          expected: 'false,true,<note><to a="foo" b="bar">Tove</to><from>Jani</from></note>' },
        { get: (doc) => {
            doc.note.setText(null);
            return doc.note.$text;
          },
          expected: '' },
        { get: (doc) => {
            doc.note.setText(undefined);
            return doc.note.$text;
          },
          expected: '' },
        { get: (doc) => {
            doc.note.removeText();
            return doc.note.$text;
          },
          expected: '' },
        { get: (doc) => {
            delete doc.note.$text;
            return xml.serializeToString(doc);
          },
          expected: `<note></note>` },
        { get: (doc) => {
            doc.note.removeText();
            return xml.serializeToString(doc);
          },
          expected: `<note></note>` },
        { get: (doc) => {
            let to = doc.note.to;
            doc.$root.$text = '';
            return [to.$name, to.$text, to.$attr$b, to.$parent].toString();
          },
          expected: 'to,Tove,bar,' },
        { get: (doc) => {
            doc.note.to.setAttribute('aaa', 'foo');
            doc.note.to.setAttribute('bbb', '<bar\"');
            return xml.serializeToString(doc.note.to);
          },
          expected: `<to a="foo" aaa="foo" b="bar" bbb="&lt;bar&quot;">Tove</to>` },
        { get: (doc) => {
            doc.note.to.$attr$aaa = 'foo';
            doc.note.to.$attr$bbb = '<bar\"';
            return xml.serializeToString(doc.note.to);
          },
          expected: `<to a="foo" aaa="foo" b="bar" bbb="&lt;bar&quot;">Tove</to>` },
        { get: (doc) => {
            doc.note.to.$attr$aaa = 'foo';
            return doc.note.to.$attr$aaa;
          },
          expected: `foo` },
        { get: (doc) => {
            doc.note.to.setAttribute('aaa', 'foo');
            doc.note.to.setAttribute('aaa', 'foo2');
            return xml.serializeToString(doc.note.to);
          },
          expected: `<to a="foo" aaa="foo2" b="bar">Tove</to>` },
        { get: (doc) => {
            let value = 'x'.repeat(2048);
            doc.note.to.setAttribute('aaa', value);
            doc.note.to.$attr$bbb = value;
            return [doc.note.to.$attr$aaa.length,
                    doc.note.to.$attr$bbb.length].toString();
          },
          expected: '2048,2048' },
        { get: (doc) => {
            let called = false;
            let value = {toString: () => {
                called = true;
                doc.note.removeChildren('to');
                return 'changed';
            }};

            try {
                doc.note.to.setAttribute('aaa', value);
            } catch (e) {
                return [called, e instanceof TypeError,
                        xml.serializeToString(doc)].toString();
            }

            return 'missing exception';
          },
          expected: 'false,true,<note><to a="foo" b="bar">Tove</to><from>Jani</from></note>' },
        { get: (doc) => {
            doc.note.to.removeAttribute('a');
            return xml.serializeToString(doc.note.to);
          },
          expected: `<to b="bar">Tove</to>` },
        { get: (doc) => {
            doc.note.to.removeAllAttributes();
            return xml.serializeToString(doc.note.to);
          },
          expected: `<to>Tove</to>` },
        { get: (doc) => {
            let attrs = doc.note.to.$attrs;
            doc.note.to.removeAllAttributes();
            return attrs.a;
          },
          expected: undefined },
        { get: (doc) => {
            let to = doc.note.to;
            let attrs = doc.note.to.$attrs;
            to.removeAllAttributes();
            return attrs.a;
          },
          expected: undefined },
        { get: (doc) => {
            delete doc.note.to.$attr$a;
            return xml.serializeToString(doc.note.to);
          },
          expected: `<to b="bar">Tove</to>` },
        { get: (doc) => {
            doc.note.to.setAttribute('a', null);
            return xml.serializeToString(doc.note.to);
          },
          expected: `<to b="bar">Tove</to>` },
        { get: (doc) => {
            doc.note.to.setAttribute('<', 'foo');
            return xml.serializeToString(doc.note.to);
          },
          exception: 'TypeError: attribute name "<" is not valid' },
        { get: (doc) => {
            let doc2 = xml.parse(`<n0:pdu xmlns:n0=\"http://a\"></n0:pdu>`);
            doc.note.addChild(doc2);
            return xml.serializeToString(doc);
            },
          exception: 'TypeError: XMLNode has namespaces' },
        { get: (doc) => {
            let doc2 = xml.parse(`<child>value</child>`);
            doc.note.addChild(doc2);
            doc.note.addChild(doc2);
            return xml.serializeToString(doc);
            },
          expected: '<note><to a="foo" b="bar">Tove</to><from>Jani</from>'
                    + '<child>value</child><child>value</child></note>' },
        { get: (doc) => {
            let source = xml.parse(`<!DOCTYPE root [<!ENTITY e "text">]><root>&e;</root>`);

            try {
                doc.note.addChild(source.root);
            } catch (e) {
                return e instanceof TypeError;
            }

            return false;
          },
          expected: true },
        { get: (doc) => {
            doc.note.removeChildren('to');
            return xml.serializeToString(doc);
          },
          expected: `<note><from>Jani</from></note>` },
        { get: (doc) => {
            delete doc.note.$tag$to;
            return xml.serializeToString(doc);
          },
          expected: `<note><from>Jani</from></note>` },
        { get: (doc) => {
            delete doc.note.to;
            return xml.serializeToString(doc);
          },
          expected: `<note><from>Jani</from></note>` },
        { get: (doc) => {
            doc.note.removeChildren('xxx');
            return xml.serializeToString(doc);
          },
          expected: `<note><to a="foo" b="bar">Tove</to><from>Jani</from></note>` },
        { get: (doc) => {
            delete doc.note.$tag$xxx;
            return xml.serializeToString(doc);
          },
          expected: `<note><to a="foo" b="bar">Tove</to><from>Jani</from></note>` },
        { get: (doc) => {
            try {
                doc.note.$tag$xxx = doc.note.to;
            } catch (e) {
                if (e instanceof TypeError) {
                    return 'OK';
                }
            }

            throw Error('unexpected exception');
          },
          expected: 'OK' },
        { get: (doc) => {
            try {
                doc.note.$tag$to = null;
            } catch (e) {
                return [e instanceof TypeError, doc.note.to.$text].toString();
            }

            return 'missing exception';
          },
          expected: 'true,Tove' },
        { get: (doc) => {
            try {
                doc.note.$tag$to = undefined;
            } catch (e) {
                return [e instanceof TypeError, doc.note.to.$text].toString();
            }

            return 'missing exception';
          },
          expected: 'true,Tove' },
        { get: (doc) => {
            try {
                delete doc.note.$tags$to;
            } catch (e) {
                return [e instanceof TypeError,
                        doc.note.$tags$to.length].toString();
            }

            return 'missing exception';
          },
          expected: 'true,1' },
        { doc: `<root><a>A</a><b>B</b><c>C</c><a>D</a></root>`,
          get: (doc) => {
            let b = doc.root.b;
            let c = doc.root.c;
            doc.$root.removeChildren('a');
            b.setText('changed');
            c.setAttribute('x', 'y');
            return xml.serializeToString(doc);
          },
          expected: '<root><b>changed</b><c x="y">C</c></root>' },
        { doc: `<root><a>A</a><b>B</b><a>C</a></root>`,
          get: (doc) => {
            doc.$root.removeChildren();
            return xml.serializeToString(doc);
          },
          expected: `<root></root>` },
        { doc: `<root><a>A</a><b>B</b><a>C</a></root>`,
          get: (doc) => {
            doc.$root.$tags = [];
            return xml.serializeToString(doc);
          },
          expected: `<root></root>` },
        { doc: `<root><a>A</a><b>B</b><a>C</a></root>`,
          get: (doc) => {
            doc.$root.$tags$ = [];
            return xml.serializeToString(doc);
          },
          expected: `<root></root>` },
        { doc: `<root></root>`,
          get: (doc) => {
            delete doc.root.$tags;
            return xml.serializeToString(doc);
          },
          expected: `<root></root>` },
        { doc: `<root><a>A</a></root>`,
          get: (doc) => {
            delete doc.root.$tags;
            return xml.serializeToString(doc);
          },
          expected: `<root></root>` },
        { doc: `<root></root>`,
          get: (doc) => {
            let source = xml.parse(`<child>value</child>`);
            doc.root.$tags = [source];
            return xml.serializeToString(doc);
          },
          expected: `<root><child>value</child></root>` },
        { doc: `<root></root>`,
          skip: () => !has_quickjs(),
          get: (doc) => {
            let values = [];

            Object.defineProperty(values, '0', {
                get: () => xml.parse(`<child>value</child>`),
            });
            Object.defineProperty(values, 'length', {value: 1});

            doc.root.$tags = values;
            return xml.serializeToString(doc);
          },
          expected: `<root><child>value</child></root>` },
        { doc: `<root><target><old>value</old></target></root>`,
          skip: () => !has_quickjs(),
          get: (doc) => {
            let source = xml.parse(`<new></new>`);
            let target = doc.root.target;
            let values = [];

            Object.defineProperty(values, '0', {
                get: () => {
                    doc.root.removeChildren('target');
                    return source;
                },
            });
            Object.defineProperty(values, 'length', {value: 1});

            try {
                target.$tags = values;
            } catch (e) {
                return [e instanceof TypeError, target.$parent,
                        xml.serializeToString(doc),
                        target.$name, target.$text].toString();
            }

            return 'missing exception';
          },
          expected: 'true,,<root></root>,target,value' },
        { doc: `<root><a>A</a><b>B</b></root>`,
          get: (doc) => {
            let source = xml.parse(`<child/>`);

            try {
                doc.root.$tags$a = [source];
            } catch (e) {
                return [e instanceof TypeError, xml.serializeToString(doc)].toString();
            }

            return 'missing exception';
          },
          expected: 'true,<root><a>A</a><b>B</b></root>' },
        { doc: `<root><a>A</a></root>`,
          get: (doc) => {
            let values = new Array(2147483648);

            try {
                doc.root.$tags = values;
            } catch (e) {
                return xml.serializeToString(doc);
            }

            return 'missing exception';
          },
          expected: '<root><a>A</a></root>' },
        { doc: `<root><a>A</a><b>B</b><a>C</a></root>`,
          get: (doc) => {
            delete doc.$root.$tag$a;
            return xml.serializeToString(doc);
          },
          expected: `<root><b>B</b></root>` },
        { get: (doc) => {
            doc.note.$tags = [doc.note.to, doc.note.from];
            return xml.serializeToString(doc);
            },
          expected: '<note><to a="foo" b="bar">Tove</to>'
                    + '<from>Jani</from></note>' },
        { get: (doc) => {
            let doc2 = xml.parse(`<n0:pdu xmlns:n0=\"http://a\"></n0:pdu>`);
            doc.note.$tags = [doc.note.to, doc2];
            return xml.serializeToString(doc);
            },
          exception: 'TypeError: setval[1] has namespaces' },
        { get: (doc) => {
            let doc2 = xml.parse(`<n0:pdu xmlns:n0=\"http://a\"></n0:pdu>`);
            doc.note.$tags = [doc2, doc.note.to];
            return xml.serializeToString(doc);
            },
          exception: 'TypeError: setval[0] has namespaces' },
        { get: () => {
            let mutations = [
                (node) => node.addChild(xml.parse(`<new></new>`)),
                (node) => node.removeChildren(),
                (node) => node.removeChildren('child'),
                (node) => { delete node.$tag$child; },
                (node) => { node.$tags = []; },
                (node) => { delete node.$tags; },
            ];
            let passed = 0;

            for (let i = 0; i < mutations.length; i++) {
                let current = xml.parse(
                    `<r><target><child>C</child></target></r>`);
                let target = current.r.target;
                let mutate = mutations[i];
                current.r.removeChildren('target');

                try {
                    mutate(target);

                } catch (e) {
                    if (e instanceof TypeError
                        && target.$parent === undefined
                        && xml.serializeToString(current) == '<r></r>'
                        && target.$name == 'target'
                        && target.$text == 'C')
                    {
                        passed++;
                        continue;
                    }
                }

                return false;
            }

            return passed;
          },
          expected: 6 },
        { doc: `<r><a><b>B</b></a></r>`,
          get: (doc) => {
            let a = doc.r.a;
            let b = a.b;
            doc.r.removeChildren('a');

            try {
                b.setText('changed');
            } catch (e) {
                return [a.$parent, b.$parent.$name, b.$text,
                        e instanceof TypeError].toString();
            }

            return 'missing exception';
          },
          expected: ',a,B,true' },
        { get: (doc) => {
            let to = doc.note.to;
            doc.note.removeChildren('to');

            try {
                to.setText('changed');
            } catch (e) {
                return [to.$parent, to.$text, e instanceof TypeError].toString();
            }

            return 'missing exception';
          },
          expected: ',Tove,true' },
        { get: (doc) => {
            let to = doc.note.to;
            doc.note.removeChildren('to');

            try {
                to.setAttribute('x', 'y');
            } catch (e) {
                return e instanceof TypeError;
            }

            return false;
          },
          expected: true },
        { get: (doc) => {
            let to = doc.note.to;
            doc.note.removeChildren('to');

            try {
                to.removeAllAttributes();
            } catch (e) {
                return e instanceof TypeError;
            }

            return false;
          },
          expected: true },
        { get: (doc) => {
            let to = doc.note.to;
            doc.note.removeChildren('to');

            try {
                xml.exclusiveC14n(to);
            } catch (e) {
                return e instanceof TypeError;
            }

            return false;
          },
          expected: true },
]};

run([
    parse_tsuite,
    parse_failure_tsuite,
    c14n_tsuite,
    modify_tsuite,
])
.then($DONE, $DONE);
